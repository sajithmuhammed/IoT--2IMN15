package org.eclipse.leshan.server.demo;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.ArrayList;
import java.net.ResponseCache;

import org.eclipse.californium.core.network.Endpoint;
import org.eclipse.californium.core.network.Exchange;
import org.eclipse.californium.core.observe.ObserveRelation;
import org.eclipse.californium.core.server.resources.Resource;
import org.eclipse.californium.core.server.resources.ResourceAttributes;
import org.eclipse.californium.core.server.resources.ResourceObserver;
//import org.eclipse.leshan.standalone.BrokerState;
import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.coap.CoAP.ResponseCode;
import org.eclipse.californium.core.coap.OptionSet;
import org.eclipse.californium.core.coap.Response;
import org.eclipse.californium.core.server.resources.CoapExchange;

public class SetCamera extends CoapResource {
	
	private brokerState BrokerState = brokerState.getInstance();
	
	private void log(String message){
		System.out.println("Camera Registeration: "+ message);
	}
	
	public SetCamera(String name) {
		super(name);	
	}
	
	@Override
	public void handleGET(CoapExchange exchange){
		exchange.respond("camera ");
	}
	
	@Override
	public void handlePOST(CoapExchange exchange){
		exchange.accept();
		
		OptionSet optionSet = exchange.getRequestOptions();
				
		String cameradevice = optionSet.getUriQueryString();//give condition for sensor ; if user is registered
		
		exchange.respond(ResponseCode.CREATED);			
/*		if (BrokerState.registerCamera(cameradevice)){
				exchange.respond(ResponseCode.CREATED);				
				log(cameradevice + " successfully registered!");
								
		}
		else{
			exchange.respond(ResponseCode.BAD_OPTION);				
			log(cameradevice + " already registered!");
		}	*/
	}
}