package org.eclipse.leshan.server.demo;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.ArrayList;
import java.net.ResponseCache;

import org.eclipse.californium.core.network.Endpoint;
import org.eclipse.californium.core.network.Exchange;
import org.eclipse.californium.core.observe.ObserveRelation;
import org.eclipse.californium.core.server.resources.Resource;
import org.eclipse.californium.core.server.resources.ResourceAttributes;
import org.eclipse.californium.core.server.resources.ResourceObserver;
import org.eclipse.leshan.core.model.ResourceModel.Type;
import org.eclipse.leshan.core.node.LwM2mSingleResource;
import org.eclipse.leshan.core.request.WriteRequest;
import org.eclipse.leshan.core.request.WriteRequest.Mode;
import org.eclipse.leshan.server.californium.impl.LeshanServer;
//import org.eclipse.leshan.standalone.BrokerState;
import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.coap.CoAP.ResponseCode;
import org.eclipse.californium.core.coap.OptionSet;
import org.eclipse.californium.core.coap.Response;
import org.eclipse.californium.core.server.resources.CoapExchange;
import org.eclipse.leshan.server.client.Registration;
//import org.eclipse.leshan.standalone.Client;
//import org.eclipse.leshan.standalone.LwM2mSingleResource;
//import org.eclipse.leshan.standalone.WriteRequest;
import org.eclipse.leshan.server.demo.servlet.EventServlet;

public class SetLight extends CoapResource {
	
	private brokerState BrokerState = brokerState.getInstance();
	private LeshanServer lwServer = null;
	private EventServlet eventServlet = null;
	private String resultstring = "";
	public SetLight(String name, LeshanServer lwServer, EventServlet eventServlet) {
		super(name);
		this.lwServer = (LeshanServer)lwServer;
		this.eventServlet = eventServlet;
		//this.resultstring=resultstring;
	}

	private void log(String message){
		System.out.println("Light Registeration: "+ message);
	}
	
	private static final String GROUP_NUMBER_LIGHT = "/10250/0/7";
	private static final String LOCATION_X_LIGHT = "/10250/0/8";
	private static final String LOCATION_Y_LIGHT = "/10250/0/9";
	private static final String ROOM_ID_LIGHT = "/10250/0/10";	
	
	private static final long TIMEOUT = 5000; // ms
	
	@Override
	public void handleGET(CoapExchange exchange){
		exchange.respond("light ");
	}
	
	@Override
	public void handlePOST(CoapExchange exchange){
		exchange.accept();
		
		OptionSet optionSet = exchange.getRequestOptions();
				
		String lightdevice = optionSet.getUriQueryString();//give condition for light ; if user is registered
		//leshanServer = (LeshanServer)leshanServer;
//		Registration registration;	
		exchange.respond(ResponseCode.CREATED);	
	/*	if (BrokerState.registerLight(lightdevice)){
				exchange.respond(ResponseCode.CREATED);				
				log(lightdevice + " successfully registered!");
			//	brokerState.registerLightdevice(registration.getEndpoint(), );      
				
		}		
		else{
			exchange.respond(ResponseCode.BAD_OPTION);				
			log(lightdevice + " already registered!");
		}	
		 LightIdentity light=new LightIdentity(resultstring, lwServer, eventServlet);
		*/   
		// LightIdentity light=new LightIdentity(resultstring, lwServer, eventServlet);
		//light.handling();
		String groupNumber = "1";
		String locationX = "2";
		String locationY = "3";
		String roomID = "4";
	/*	Registration registration = lwServer.getRegistrationService().getByEndpoint("windowsClient");
		System.out.println(registration);
   		LwM2mSingleResource node = LwM2mSingleResource.newResource(5603, 10.0, Type.FLOAT);			
   		try {
   			lwServer.send(registration, new WriteRequest(Mode.REPLACE, null, "/3303/0/5603", node));

   			
   		} catch (InterruptedException e) {
   			// TODO Auto-generated catch block
   			e.printStackTrace();
   		}*/
	}
}