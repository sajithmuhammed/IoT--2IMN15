package org.eclipse.leshan.server.demo;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.swing.text.html.HTMLDocument.HTMLReader.ParagraphAction;

import org.eclipse.californium.core.coap.CoAP.ResponseCode;


public class brokerState {
	private static brokerState instance = null;
	public static brokerState getInstance(){
		if(instance == null){
			instance = new brokerState();
		}
		
		return instance;
	}
	private brokerState(){
		
	}
	static ArrayList<String> registerLight = new ArrayList<>();
	static ArrayList<String> registerCamera = new ArrayList<>();



/*	public static boolean registerLight(String lightdevice){
		if (registerLight.contains(lightdevice)){		
			return false;
		}
		else{
			registerLight.add(lightdevice);
			return true;
		}
	}	
	
	public static boolean registerCamera(String cameradevice){
		if (registerCamera.contains(cameradevice)){		
			return false;
		}
		else{
			registerCamera.add(cameradevice);
			return true;
		}
	}*/
	public static String registeredLights(String deviceDetails) {
		String[] queryVariables = deviceDetails.split("-");
		if(queryVariables[0] == "Light")
		{
			registerLight.add(deviceDetails);
		}
		else{
			registerCamera.add(deviceDetails);
		}//System.out.println(groupNumber);
		return null;
	}


}