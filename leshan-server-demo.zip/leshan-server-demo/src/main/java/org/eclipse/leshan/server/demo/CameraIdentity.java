package org.eclipse.leshan.server.demo;

import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.coap.OptionSet;
import org.eclipse.californium.core.coap.Response;
import org.eclipse.californium.core.coap.CoAP.ResponseCode;
import org.eclipse.californium.core.server.resources.CoapExchange;
import org.eclipse.leshan.core.model.ResourceModel.Type;
import org.eclipse.leshan.core.node.LwM2mNode;
import org.eclipse.leshan.core.node.LwM2mSingleResource;
import org.eclipse.leshan.core.request.ObserveRequest;
import org.eclipse.leshan.core.request.WriteRequest;
import org.eclipse.leshan.core.request.WriteRequest.Mode;
import org.eclipse.leshan.core.response.ObserveResponse;
import org.eclipse.leshan.server.LwM2mServer;
import org.eclipse.leshan.server.californium.impl.LeshanServer;
import org.eclipse.leshan.server.client.Registration;
import org.eclipse.leshan.server.demo.servlet.EventServlet;
//import org.eclipse.leshan.standalone.Client;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.ExecutorService;

import org.eclipse.californium.core.network.Endpoint;
import org.eclipse.californium.core.network.Exchange;
import org.eclipse.californium.core.observe.ObserveRelation;
import org.eclipse.californium.core.server.resources.Resource;
import org.eclipse.californium.core.server.resources.ResourceAttributes;
import org.eclipse.californium.core.server.resources.ResourceObserver;

public class CameraIdentity extends CoapResource {

	
	private brokerState BrokerState = brokerState.getInstance();
	private LeshanServer lwServer = null;
	private EventServlet eventServlet = null;
	
	private static final String GROUP_NUMBER_CAMERA = "/10350/0/7";
	private static final String LOCATION_X_CAMERA = "/10350/0/8";
	private static final String LOCATION_Y_CAMERA = "/10350/0/9";
	private static final String ROOM_ID_CAMERA = "/10350/0/10";	
	
	//private static final long TIMEOUT = 5000; // ms
	
	private void log(String message){
		System.out.println("CameraIdentity : "+ message);
	}
	public CameraIdentity(String name, LwM2mServer leshanServer, EventServlet eventServlet) {
		super(name);
		this.lwServer = (LeshanServer)leshanServer;
		this.eventServlet = eventServlet;
	}
	
	@Override
	public void handlePOST(CoapExchange exchange) {
		OptionSet optionSet = exchange.getRequestOptions();
		String queryString = optionSet.getUriQueryString();
		int groupNumber;
		float locationX;
		float locationY;
		String roomID;
		
		// split on &
		String[] queryVariables = queryString.split(";");
		
		// for each variable, split on = and extract the values
				
		groupNumber = 1;//queryVariables[0];
		locationX = 3/2;//queryVariables[1];
		locationY = 3/2;//queryVariables[2];
		roomID = "as";//queryVariables[3];
		
/*		Registration registration = lwServer.getRegistrationService().getByEndpoint("IoT-Pi41");/////////////////////////////////////
		//System.out.println(registration);
   		LwM2mSingleResource node = LwM2mSingleResource.newResource(7, groupNumber, Type.INTEGER);			
   		try {
   			lwServer.send(registration, new WriteRequest(Mode.REPLACE, null, GROUP_NUMBER_CAMERA, node));
   		} catch (InterruptedException e) {
   			// TODO Auto-generated catch block
   			e.printStackTrace();
   		}
   		 node = LwM2mSingleResource.newResource(8, locationX, Type.FLOAT);			
   		try {
   			lwServer.send(registration, new WriteRequest(Mode.REPLACE, null, LOCATION_X_CAMERA, node));
   		} catch (InterruptedException e) {
   			// TODO Auto-generated catch block
   			e.printStackTrace();
   		}
   		 node = LwM2mSingleResource.newResource(9, locationY, Type.FLOAT);			
   		try {
   			lwServer.send(registration, new WriteRequest(Mode.REPLACE, null, LOCATION_Y_CAMERA, node));
   		} catch (InterruptedException e) {
   			// TODO Auto-generated catch block
   			e.printStackTrace();
   		}
   		 node = LwM2mSingleResource.newResource(10, roomID, Type.STRING);			
   		try {
   			lwServer.send(registration, new WriteRequest(Mode.REPLACE, null, ROOM_ID_CAMERA, node));
   		} catch (InterruptedException e) {
   			// TODO Auto-generated catch block
   			e.printStackTrace();
   		}*/
	}


	

}